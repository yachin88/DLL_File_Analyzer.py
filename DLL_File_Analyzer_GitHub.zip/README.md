# 🧪 DLL File Analyzer

A simple Windows GUI tool to analyze `.dll` files. It checks:
- ✅ SHA256 Hash
- 🔐 Digital Signature (using PowerShell)
- 🔗 Gives you a link to check the hash on [VirusTotal](https://www.virustotal.com)

## 📦 Features

- Easy drag-and-browse interface
- Shows full certificate and signing info
- No upload, fully local analysis
- Built with Python + Tkinter

## 🚀 How to Run

1. Make sure you have **Python 3.x** installed.
2. Run this in terminal:
   ```bash
   python DLL_File_Analyzer.py
   ```

## 🛠 Convert to EXE (Optional)

Want to make a Windows `.exe`?

```bash
pip install pyinstaller
pyinstaller --noconsole --onefile DLL_File_Analyzer.py
```

Output will be in the `dist/` folder.

## 📄 License

This tool is open-source for educational use.